module.exports.competitionCode = {
  100000004: "LCK",
  100000006: "World Championship",
  100000007: "Mid-Season Invitational",
  100000008: "Rift Rivals",
}
