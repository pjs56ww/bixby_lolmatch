module.exports.competitionCode = {
  "LCK": [100000004],
  "World Championship" : [100000006],
}
