module.exports.teamCode = {
  "SKT T1" : 100000010,
  "Damwon" : 100000154,
  "Griffin" : 100000065,
}
  
